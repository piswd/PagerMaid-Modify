#!/bin/sh
while :
do
  clear
  python3 -m pagermaid
  echo '正在重新启动...'
  sleep 1
done
